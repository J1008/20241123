####################三个顶点组成的三角形（斑块的统计）#####
######### 预聚类
# 载入必要的库
library(dplyr)
library(proxy)
library(igraph)
library(openxlsx)

# 读取所有CSV文件并合并
files <- list.files(path = "data_ori", pattern = "\\.csv$", full.names = TRUE)
all_data <- lapply(files, read.csv, header = TRUE) %>% bind_rows()

# 去重，假设'name'列包含物种名
distinct_data <- all_data %>% distinct(name, .keep_all = TRUE)
distinct_data <- distinct_data[, -2]

# 预处理数据，假设第一列是物种名
# 使用dplyr进行数据标准化
distinct_data <- distinct_data %>%
  mutate(across(-name, scale))  # 假设第一列是名为'name'的物种名称列
trait_data <- distinct_data[, -1]

# 计算相似度矩阵
similarity <- proxy::simil(trait_data, method = "cosine")
similarity <- as.matrix(similarity)

# 确保行名和列名正确
rownames(similarity) <- distinct_data$name
colnames(similarity) <- distinct_data$name

# 将相似度矩阵中的不合理值调整为合理范围
similarity[similarity > 1] <- 1
similarity[similarity < 0] <- 0

######### 3D。 合并所有状态外壳 
# 提取文件名中的地名和时期信息的函数
extract_info_from_filename <- function(filename) {
  name_parts <- strsplit(basename(filename), "——")[[1]]
  location <- name_parts[1]
  period <- name_parts[2]
  period <- sub(".csv", "", period)
  return(list(location = location, period = period))
}

# 计算物种状态的函数
calculate_species_status <- function(data1, data2) {
  new_species <- setdiff(data2$name, data1$name)
  disappeared_species <- setdiff(data1$name, data2$name)
  constant_species <- intersect(data1$name, data2$name)
  
  status <- data.frame(
    name = c(new_species, disappeared_species, constant_species),
    status = c(rep("new", length(new_species)), 
               rep("disappeared", length(disappeared_species)), 
               rep("constant", length(constant_species)))
  )
  
  return(status)
}

# 读取数据并提取信息
early_data_filename <- "data_ori/CaH——HIS.csv"
mid_data_filename <- "data_ori/CaH——7080.csv"
late_data_filename <- "data_ori/CaH——now.csv"

early_data_info <- extract_info_from_filename(early_data_filename)
mid_data_info <- extract_info_from_filename(mid_data_filename)
late_data_info <- extract_info_from_filename(late_data_filename)

early_data <- read.csv(early_data_filename)
mid_data <- read.csv(mid_data_filename)
late_data <- read.csv(late_data_filename)
similarity_matrix <- similarity  # 确保 similarity 是相似度矩阵的变量名

# 合并数据
merged_early_mid <- unique(rbind(early_data, mid_data))
merged_mid_late <- unique(rbind(mid_data, late_data))

# 计算物种状态
early_mid_status <- calculate_species_status(early_data, mid_data)
mid_late_status <- calculate_species_status(mid_data, late_data)

# 创建网络图对象
Isite_Fin_early_mid <- similarity_matrix[merged_early_mid$name, merged_early_mid$name]
diag(Isite_Fin_early_mid) <- 0
Isite_Fin_early_mid[Isite_Fin_early_mid < 0] <- 0
Isite_net_early_mid <- graph_from_adjacency_matrix(Isite_Fin_early_mid, weighted = TRUE, mode = 'undirected')

Isite_Fin_mid_late <- similarity_matrix[merged_mid_late$name, merged_mid_late$name]
diag(Isite_Fin_mid_late) <- 0
Isite_Fin_mid_late[Isite_Fin_mid_late < 0] <- 0
Isite_net_mid_late <- graph_from_adjacency_matrix(Isite_Fin_mid_late, weighted = TRUE, mode = 'undirected')

# 生成3D布局
layout_3d_early_mid <- layout_with_fr(Isite_net_early_mid, dim = 3)
layout_3d_mid_late <- layout_with_fr(Isite_net_mid_late, dim = 3)

# 返回3D坐标和网络对象
list(
  early_mid = list(network = Isite_net_early_mid, layout = layout_3d_early_mid),
  mid_late = list(network = Isite_net_mid_late, layout = layout_3d_mid_late)
)

# 计算网络中的所有三角形
calculate_triangles <- function(network) {
  triangles_list <- triangles(network)
  triangles_matrix <- matrix(triangles_list, ncol = 3, byrow = TRUE)
  return(triangles_matrix)
}

# 生成零模型网络的函数
generate_null_model <- function(network, num_state, state) {
  node_names <- V(network)$name
  repeat {
    random_status <- sample(c(rep(state, num_state), 
                              rep("other", vcount(network) - num_state)))
    if (!all(V(network)$status == random_status)) {
      break
    }
  }
  null_network <- network
  V(null_network)$status <- random_status
  return(null_network)
}

# 生成3D布局并计算三角形分析
process_triangles <- function(network, status_data, title, period, location, state) {
  # 确保网络的状态已正确分配
  V(network)$status <- ifelse(V(network)$name %in% status_data$name[status_data$status == state], state, "other")
  
  # 检查状态物种数量
  num_state <- sum(V(network)$status == state)
  if (num_state < 3) {
    cat("Not enough data for", title, "(", state, ")\n")
    return(data.frame(
      Period = period,
      Location = location,
      State = state,
      State_Species_Triangles = "NED",
      Total_Triangles = "NED",
      Null_Model_Mean_State_Triangles = "NED",
      Null_Model_State_Triangles_SD = "NED",
      Z_score = "NED",
      P_value = "NED",
      State_Species_Count = num_state
    ))
  }
  
  # 计算网络中的所有三角形
  triangles <- calculate_triangles(network)
  cat("Triangles calculated for", title, "(", state, "):\n")
  print(head(triangles, 10))  # 只打印前10个三角形信息
  
  # 如果三角形数量为零，返回错误信息
  if (nrow(triangles) == 0) {
    cat("No triangles found in the network for", title, "(", state, ")\n")
    return(data.frame(
      Period = period,
      Location = location,
      State = state,
      State_Species_Triangles = "NED",
      Total_Triangles = "NED",
      Null_Model_Mean_State_Triangles = "NED",
      Null_Model_State_Triangles_SD = "NED",
      Z_score = "NED",
      P_value = "NED",
      State_Species_Count = num_state
    ))
  }
  
  # 统计至少三个标记物种组成的三角形数量
  state_triangles <- sum(apply(triangles, 1, function(triangle) {
    sum(V(network)$status[triangle] == state) >= 3
  }))
  total_triangles <- nrow(triangles)
  
  # 计算零模型的三角形分布情况
  null_state_triangles <- numeric(1000)
  
  pb <- txtProgressBar(min = 0, max = 1000, style = 3)  # 创建进度条
  
  for (i in 1:1000) {
    null_model <- generate_null_model(network, num_state, state)
    null_triangles <- calculate_triangles(null_model)
    
    # 如果三角形数量为零，继续下一次迭代
    if (nrow(null_triangles) == 0) {
      next
    }
    
    null_state_triangles[i] <- sum(apply(null_triangles, 1, function(triangle) {
      sum(V(null_model)$status[triangle] == state) >= 3
    }))
    
    setTxtProgressBar(pb, i)  # 更新进度条
  }
  
  close(pb)  # 关闭进度条
  
  # 计算零模型的均值和标准差
  null_mean <- mean(null_state_triangles)
  null_sd <- sd(null_state_triangles)
  
  cat("Null Model Mean", state, "Triangles:", null_mean, "\n")
  cat("Null Model", state, "Triangles SD:", null_sd, "\n")
  
  # 计算z分数和p值
  z_score <- (state_triangles - null_mean) / null_sd
  p_value <- 2 * (1 - pnorm(abs(z_score)))
  
  # 如果P值小于机器精度的下限，将其设置为接近零的最小值
  if (p_value == 0) {
    p_value <- .Machine$double.eps
  }
  
  # 输出结果
  cat("Results for", title, "(", state, "):\n")
  cat(state, "Species Triangles:", state_triangles, "\n")
  cat("Total Triangles:", total_triangles, "\n")
  cat("Z-score:", z_score, "\n")
  cat("P-value:", p_value, "\n")
  
  # 检验结果
  if (!is.na(p_value) && p_value < 0.05) {
    cat("The", state, "species show significant clustering in triangles (p < 0.05).\n")
  } else {
    cat("The", state, "species do not show significant clustering in triangles (p >= 0.05).\n")
  }
  
  # 返回结果数据框
  return(data.frame(
    Period = period,
    Location = location,
    State = state,
    State_Species_Triangles = state_triangles,
    Total_Triangles = total_triangles,
    Null_Model_Mean_State_Triangles = null_mean,
    Null_Model_State_Triangles_SD = null_sd,
    Z_score = z_score,
    P_value = p_value,
    State_Species_Count = num_state
  ))
}

# 初始化结果数据框
results_df <- data.frame()

# 处理每个时期和状态的网络
for (state in c("disappeared", "new", "constant")) {
  results_df <- rbind(results_df, process_triangles(Isite_net_early_mid, early_mid_status, "Early-Mid Period", "Early-Mid", early_data_info$location, state))
  results_df <- rbind(results_df, process_triangles(Isite_net_mid_late, mid_late_status, "Mid-Late Period", "Mid-Late", mid_data_info$location, state))
}

# 创建文件夹
if (!dir.exists("Hyp_test")) {
  dir.create("Hyp_test")
}

# 保存结果到Excel文件
write.xlsx(results_df, file = paste0("Hyp_test/results_", early_data_info$location, ".xlsx"))
