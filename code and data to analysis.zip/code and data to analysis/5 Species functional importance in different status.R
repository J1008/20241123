######合并功能和网络距离#####
library(readxl)
library(openxlsx)
library(dplyr)

# 读取function和network文件
function_file <- "function.xlsx"
network_file <- "network.xlsx"

# 读取两个时期的单元薄
function_em <- read_excel(function_file, sheet = "E-M")
function_ml <- read_excel(function_file, sheet = "M-L")
network_em <- read_excel(network_file, sheet = "E-M")
network_ml <- read_excel(network_file, sheet = "M-L")

# 合并两个时期的单元薄
merged_em <- inner_join(function_em, network_em, by = c("Species", "Status", "Location"))
merged_ml <- inner_join(function_ml, network_ml, by = c("Species", "Status", "Location"))

# 写入新的Excel文件
write.xlsx(list("E-M" = merged_em, "M-L" = merged_ml), file = "merged_file.xlsx")

######统计频数#####
library(readxl)
library(dplyr)
library(openxlsx)

# 读取合并后的文件
merged_file <- "merged_file.xlsx"

# 读取两个时期的单元薄
merged_em <- read_excel(merged_file, sheet = "E-M")
merged_ml <- read_excel(merged_file, sheet = "M-L")

# 定义计算出现频率的函数
calculate_appearance_frequency <- function(df) {
  # 统计每个物种在每种状态下的出现次数
  frequency <- df %>%
    group_by(Species, Status) %>%
    summarise(count = n(), .groups = 'drop') %>%
    mutate(appearance_frequency = count / 15)
  
  # 将频率合并回原数据框
  df <- left_join(df, frequency, by = c("Species", "Status"))
  return(df)
}

# 应用函数到两个单元薄
merged_em <- calculate_appearance_frequency(merged_em)
merged_ml <- calculate_appearance_frequency(merged_ml)

# 写入新的Excel文件
write.xlsx(list("E-M" = merged_em, "M-L" = merged_ml), file = "updated_merged_file.xlsx")

######统计频数，计算平均值#####
library(readxl)
library(dplyr)
library(openxlsx)

# 读取合并后的文件
merged_file <- "merged_file.xlsx"

# 读取两个时期的单元薄
merged_em <- read_excel(merged_file, sheet = "E-M")
merged_ml <- read_excel(merged_file, sheet = "M-L")

# 定义计算频率和平均值的函数
calculate_appearance_and_averages <- function(df) {
  # 统计每个物种在每种状态下的出现次数和平均值
  frequency <- df %>%
    group_by(Species, Status) %>%
    summarise(
      count = n(),
      Func_role_distance_avg = mean(Func_role_distance, na.rm = TRUE),
      network_role_distance_avg = mean(network_role_distance, na.rm = TRUE),
      .groups = 'drop'
    ) %>%
    mutate(appearance_frequency = count / 15)
  
  return(frequency)
}

# 应用函数到两个单元薄
result_em <- calculate_appearance_and_averages(merged_em)
result_ml <- calculate_appearance_and_averages(merged_ml)

# 写入新的Excel文件
write.xlsx(list("E-M" = result_em, "M-L" = result_ml), file = "ave_merged_file.xlsx")



#######热图绘制######
library(readxl)
library(dplyr)
library(ggplot2)
library(openxlsx)
library(akima)

# 读取Excel文件
file <- "ave_merged_file.xlsx"

# 显示单元薄名称
sheets <- excel_sheets(file)
print(sheets)

# 选择单元薄
selected_sheet <- "M-L" # 根据你的需求修改

# 读取选择的单元薄
data <- read_excel(file, sheet = selected_sheet)

# 显示列名
columns <- colnames(data)
print(columns)

# 选择x, y, z轴
x_column <- "Func_role_distance_avg" # 根据你的需求修改
y_column <- "network_role_distance_avg" # 根据你的需求修改
z_column <- "appearance_frequency" # 根据你的需求修改

# 对 x, y, z 轴进行归一化处理
data[[x_column]] <- (data[[x_column]] - min(data[[x_column]], na.rm = TRUE)) / (max(data[[x_column]], na.rm = TRUE) - min(data[[x_column]], na.rm = TRUE))
data[[y_column]] <- (data[[y_column]] - min(data[[y_column]], na.rm = TRUE)) / (max(data[[y_column]], na.rm = TRUE) - min(data[[y_column]], na.rm = TRUE))
data[[z_column]] <- (data[[z_column]] - min(data[[z_column]], na.rm = TRUE)) / (max(data[[z_column]], na.rm = TRUE) - min(data[[z_column]], na.rm = TRUE))

# 选择Status列
status_column <- "Status" # 根据你的需求修改

# 显示Status列下的分类
status_categories <- unique(data[[status_column]])
print(status_categories)

# 选择一个分类进行操作
selected_category <- "new" # 根据你的需求修改

# 筛选选定分类的数据
filtered_data <- data %>% filter(!!sym(status_column) == selected_category)

# 检查筛选后的数据是否为空
if (nrow(filtered_data) == 0) {
  stop("Filtered data is empty. Please check the selected category and data.")
}

# 内插数据，生成网格
interp_data <- with(filtered_data, interp(x = get(x_column), y = get(y_column), z = get(z_column), duplicate = "mean", nx = 150, ny = 150))

# 转换内插数据为数据框
interp_df <- data.frame(expand.grid(x = interp_data$x, y = interp_data$y), z = as.vector(interp_data$z))

# 用 ggplot2 画热图并添加轴坐标线和刻度
ggplot(interp_df, aes(x = x, y = y, fill = z)) +
  geom_tile() +
  scale_fill_gradientn(colours = c("#60A3D9", "#F8EA8C", "#FF4500"), na.value = "#60A3D9") +
  labs(x = x_column, y = y_column, fill = z_column) +
  theme_minimal() +
  theme(
    panel.grid = element_blank(), # 移除网格线
    panel.border = element_blank(), # 移除面板边框
    axis.line = element_line(color = "black"),
    axis.ticks = element_line(color = "black"),
    axis.title = element_text(size = 18),
    axis.text = element_text(size = 20),
    plot.margin = margin(t = 0, r = 0, b = 0, l = 0, unit = "cm")
  ) +
  scale_x_continuous(expand = c(0, 0), breaks = seq(0, 1, length.out = 10), labels = scales::number_format(accuracy = 0.01)) +
  scale_y_continuous(expand = c(0, 0), breaks = seq(0, 1, length.out = 10), labels = scales::number_format(accuracy = 0.01))



#########扩展坐标轴#######
library(readxl)
library(dplyr)
library(ggplot2)
library(openxlsx)
library(akima)

# 读取Excel文件
file <- "ave_merged_file.xlsx"

# 显示单元薄名称
sheets <- excel_sheets(file)
print(sheets)

# 选择单元薄
selected_sheet <- "M-L" # 根据你的需求修改

# 读取选择的单元薄
data <- read_excel(file, sheet = selected_sheet)

# 显示列名
columns <- colnames(data)
print(columns)

# 选择x, y, z轴
x_column <- "Func_role_distance_avg" # 根据你的需求修改
y_column <- "network_role_distance_avg" # 根据你的需求修改
z_column <- "appearance_frequency" # 根据你的需求修改

# 对 x, y, z 轴进行归一化处理
data[[x_column]] <- (data[[x_column]] - min(data[[x_column]], na.rm = TRUE)) / (max(data[[x_column]], na.rm = TRUE) - min(data[[x_column]], na.rm = TRUE))
data[[y_column]] <- (data[[y_column]] - min(data[[y_column]], na.rm = TRUE)) / (max(data[[y_column]], na.rm = TRUE) - min(data[[y_column]], na.rm = TRUE))
data[[z_column]] <- (data[[z_column]] - min(data[[z_column]], na.rm = TRUE)) / (max(data[[z_column]], na.rm = TRUE) - min(data[[z_column]], na.rm = TRUE))

# 选择Status列
status_column <- "Status" # 根据你的需求修改

# 显示Status列下的分类
status_categories <- unique(data[[status_column]])
print(status_categories)

# 选择一个分类进行操作
selected_category <- "new" # 根据你的需求修改

# 筛选选定分类的数据
filtered_data <- data %>% filter(!!sym(status_column) == selected_category)

# 检查筛选后的数据是否为空
if (nrow(filtered_data) == 0) {
  stop("Filtered data is empty. Please check the selected category and data.")
}

# 内插数据，生成网格
interp_data <- with(filtered_data, interp(x = get(x_column), y = get(y_column), z = get(z_column), duplicate = "mean", nx = 150, ny = 150))

# 转换内插数据为数据框
interp_df <- data.frame(expand.grid(x = interp_data$x, y = interp_data$y), z = as.vector(interp_data$z))

# 创建背景数据框，用于绘制背景色
background_df <- expand.grid(x = seq(0, 1, length.out = 150), y = seq(0, 1, length.out = 150))
background_df$z <- NA

# 创建绘图对象
p <- ggplot() +
  # 添加背景层
  geom_tile(data = background_df, aes(x = x, y = y, fill = z), fill = "#60A3D9", color = NA) +
  # 添加插值图层
  geom_tile(data = interp_df, aes(x = x, y = y, fill = z), color = NA) +
  scale_fill_gradientn(colours = c("#60A3D9", "#F8EA8C", "#FF4500"), na.value = "#60A3D9") +
  labs(x = x_column, y = y_column, fill = z_column) +
  theme_minimal() +
  theme(
    panel.grid = element_blank(), # 移除网格线
    panel.border = element_blank(), # 移除面板边框
    axis.line = element_line(color = "black"),
    axis.ticks = element_line(color = "black"),
    axis.title = element_text(size = 18),
    axis.text = element_text(size = 20),
    plot.margin = margin(t = 0, r = 0, b = 0, l = 0, unit = "cm"),
    panel.grid.major = element_blank(), # 移除主网格线
    panel.grid.minor = element_blank()  # 移除次网格线
  ) +
  scale_x_continuous(expand = c(0, 0), breaks = seq(0, 1, by = 0.25), limits = c(0, 1), labels = scales::number_format(accuracy = 0.01)) +
  scale_y_continuous(expand = c(0, 0), breaks = seq(0, 1, by = 0.25), limits = c(0, 1), labels = scales::number_format(accuracy = 0.01))

# 保存绘图为PDF文件，尺寸为10x8
output_file <- paste0(selected_sheet, "_", selected_category, ".pdf")
ggsave(output_file, plot = p, width = 10, height = 8)

# 打印保存文件路径
print(paste("Plot saved as", output_file))
