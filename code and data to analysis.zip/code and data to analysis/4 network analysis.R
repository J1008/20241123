########### 多个湖泊的计算#########
library(dplyr)
library(readxl)
library(igraph)
library(proxy)
library(openxlsx)

# 定义文件夹路径
data_folder <- "data_ori"
group_folder <- "group_result"
output_folder <- "output"

# 提取地点信息的函数
extract_location <- function(file_path) {
  sub("——.*", "", basename(file_path))
}

# 提取时期信息的函数
extract_period <- function(file_path) {
  period <- sub(".*——", "", basename(file_path))
  period <- sub("\\.csv", "", period)
  if (period == "HIS") {
    return("early")
  } else if (period == "7080") {
    return("mid")
  } else if (period == "now") {
    return("late")
  } else {
    return(NA)
  }
}

# 计算模块度的函数
calculate_modularity <- function(net, group_data) {
  V(net)$group <- NA
  matching_indices <- match(V(net)$name, group_data$Species)
  V(net)$group[!is.na(matching_indices)] <- group_data$Group[matching_indices[!is.na(matching_indices)]]
  
  if (any(is.na(V(net)$group))) {
    warning("Some species in the network do not have group information")
    V(net)$group[is.na(V(net)$group)] <- max(V(net)$group, na.rm = TRUE) + 1
  }
  
  return(modularity(net, V(net)$group))
}

# 计算平均加权度的函数
calculate_average_weighted_degree <- function(similarity_matrix) {
  sum_weights <- sum(similarity_matrix)
  num_nodes <- nrow(similarity_matrix)
  return(sum_weights / (num_nodes * (num_nodes - 1)))
}

# 计算均匀性的函数（使用香农均匀性指数）
calculate_evenness <- function(degree_vector) {
  total_degree <- sum(degree_vector)
  proportions <- degree_vector / total_degree
  shannon_index <- -sum(proportions * log(proportions))
  max_shannon_index <- log(length(degree_vector))
  evenness <- shannon_index / max_shannon_index
  return(evenness)
}

# 计算加权度的函数
calculate_weighted_degree <- function(net) {
  return(strength(net, vids = V(net), mode = "all", weights = E(net)$weight))
}

# 计算平均路径长度的函数
calculate_average_path_length <- function(net) {
  return(average.path.length(net, directed = FALSE, unconnected = TRUE))
}

# 模拟物种灭绝的函数
simulate_extinction <- function(similarity_matrix, species_names, group_data) {
  # 构建网络
  Isite_Fin <- similarity_matrix[species_names, species_names]
  rownames(Isite_Fin) <- species_names
  colnames(Isite_Fin) <- species_names
  diag(Isite_Fin) <- 0
  Isite_Fin[Isite_Fin < 0] <- 0
  Isite_net <- graph.adjacency(Isite_Fin, weighted = TRUE, mode = 'undirected')
  E(Isite_net)$correlation <- E(Isite_net)$weight
  E(Isite_net)$width <- E(Isite_net)$weight * 2
  E(Isite_net)$color <- "black"
  E(Isite_net)$weight <- abs(E(Isite_net)$weight)
  
  # 计算原始网络参数
  original_avg_weighted_degree <- calculate_average_weighted_degree(Isite_Fin)
  original_modularity <- tryCatch(calculate_modularity(Isite_net, group_data), error = function(e) NA)
  original_evenness <- tryCatch(calculate_evenness(degree(Isite_net)), error = function(e) NA)
  original_clustering <- tryCatch(transitivity(Isite_net, type = "global"), error = function(e) NA)
  original_weighted_degrees <- calculate_weighted_degree(Isite_net)
  original_avg_path_length <- tryCatch(calculate_average_path_length(Isite_net), error = function(e) NA)
  
  results <- data.frame(Species = c("All species", species_names), 
                        AvgWeightedDegree = c(original_avg_weighted_degree, rep(NA, length(species_names))),
                        Modularity = c(original_modularity, rep(NA, length(species_names))),
                        Evenness = c(original_evenness, rep(NA, length(species_names))),
                        WeightedDegree = c(NA, original_weighted_degrees),
                        Clustering = c(original_clustering, rep(NA, length(species_names))),
                        AvgPathLength = c(original_avg_path_length, rep(NA, length(species_names))),
                        AvgWeightedDegree_Difference = c(0, rep(NA, length(species_names))),
                        Modularity_Difference = c(0, rep(NA, length(species_names))),
                        Evenness_Difference = c(0, rep(NA, length(species_names))),
                        WeightedDegree_Difference = c(0, rep(NA, length(species_names))),
                        Clustering_Difference = c(0, rep(NA, length(species_names))),
                        AvgPathLength_Difference = c(0, rep(NA, length(species_names))),
                        AvgWeightedDegree_Percent_Change = c(0, rep(NA, length(species_names))),
                        Modularity_Percent_Change = c(0, rep(NA, length(species_names))),
                        Evenness_Percent_Change = c(0, rep(NA, length(species_names))),
                        WeightedDegree_Percent_Change = c(0, rep(NA, length(species_names))),
                        Clustering_Percent_Change = c(0, rep(NA, length(species_names))),
                        AvgPathLength_Percent_Change = c(0, rep(NA, length(species_names))))
  
  for (i in 1:length(species_names)) {
    species_name <- species_names[i]
    temp_matrix <- Isite_Fin[-i, -i]
    remaining_species <- species_names[-i]
    
    temp_net <- graph.adjacency(temp_matrix, weighted = TRUE, mode = 'undirected')
    temp_avg_weighted_degree <- calculate_average_weighted_degree(temp_matrix)
    temp_modularity <- tryCatch(calculate_modularity(temp_net, group_data), error = function(e) NA)
    temp_evenness <- tryCatch(calculate_evenness(degree(temp_net)), error = function(e) NA)
    temp_clustering <- tryCatch(transitivity(temp_net, type = "global"), error = function(e) NA)
    temp_avg_path_length <- tryCatch(calculate_average_path_length(temp_net), error = function(e) NA)
    
    avg_weighted_degree_difference <- temp_avg_weighted_degree - original_avg_weighted_degree
    modularity_difference <- temp_modularity - original_modularity
    evenness_difference <- temp_evenness - original_evenness
    clustering_difference <- temp_clustering - original_clustering
    avg_path_length_difference <- temp_avg_path_length - original_avg_path_length
    
    avg_weighted_degree_percent_change <- (avg_weighted_degree_difference / original_avg_weighted_degree) * 100
    modularity_percent_change <- (modularity_difference / original_modularity) * 100
    evenness_percent_change <- (evenness_difference / original_evenness) * 100
    clustering_percent_change <- (clustering_difference / original_clustering) * 100
    avg_path_length_percent_change <- (avg_path_length_difference / original_avg_path_length) * 100
    
    results$AvgWeightedDegree[i + 1] <- temp_avg_weighted_degree
    results$Modularity[i + 1] <- temp_modularity
    results$Evenness[i + 1] <- temp_evenness
    results$Clustering[i + 1] <- temp_clustering
    results$AvgPathLength[i + 1] <- temp_avg_path_length
    results$AvgWeightedDegree_Difference[i + 1] <- avg_weighted_degree_difference
    results$Modularity_Difference[i + 1] <- modularity_difference
    results$Evenness_Difference[i + 1] <- evenness_difference
    results$Clustering_Difference[i + 1] <- clustering_difference
    results$AvgPathLength_Difference[i + 1] <- avg_path_length_difference
    results$AvgWeightedDegree_Percent_Change[i + 1] <- avg_weighted_degree_percent_change
    results$Modularity_Percent_Change[i + 1] <- modularity_percent_change
    results$Evenness_Percent_Change[i + 1] <- evenness_percent_change
    results$Clustering_Percent_Change[i + 1] <- clustering_percent_change
    results$AvgPathLength_Percent_Change[i + 1] <- avg_path_length_percent_change
  }
  
  return(results)
}

# 判断物种状态并提取结果
extract_results <- function(early_data, mid_data, late_data, early_results, mid_results, late_results) {
  # Early-Mid period
  early_species <- rownames(early_data)
  mid_species <- rownames(mid_data)
  
  early_mid_status <- data.frame(Species = unique(c(early_species, mid_species)), Status = NA)
  early_mid_status$Status[early_mid_status$Species %in% early_species & !early_mid_status$Species %in% mid_species] <- "disappear"
  early_mid_status$Status[early_mid_status$Species %in% mid_species & !early_mid_status$Species %in% early_species] <- "new"
  early_mid_status$Status[early_mid_status$Species %in% early_species & early_mid_status$Species %in% mid_species] <- "unchanged"
  
  early_mid_results <- rbind(
    early_results[early_results$Species %in% early_mid_status$Species[early_mid_status$Status == "disappear"], ],
    mid_results[mid_results$Species %in% early_mid_status$Species[early_mid_status$Status != "disappear"], ]
  )
  early_mid_results <- merge(early_mid_results, early_mid_status, by = "Species")
  
  # Mid-Late period
  mid_species <- rownames(mid_data)
  late_species <- rownames(late_data)
  
  mid_late_status <- data.frame(Species = unique(c(mid_species, late_species)), Status = NA)
  mid_late_status$Status[mid_late_status$Species %in% mid_species & !mid_late_status$Species %in% late_species] <- "disappear"
  mid_late_status$Status[mid_late_status$Species %in% late_species & !mid_late_status$Species %in% mid_species] <- "new"
  mid_late_status$Status[mid_late_status$Species %in% mid_species & mid_late_status$Species %in% late_species] <- "unchanged"
  
  mid_late_results <- rbind(
    mid_results[mid_results$Species %in% mid_late_status$Species[mid_late_status$Status == "disappear"], ],
    late_results[late_results$Species %in% mid_late_status$Species[mid_late_status$Status != "disappear"], ]
  )
  mid_late_results <- merge(mid_late_results, mid_late_status, by = "Species")
  
  return(list(early_mid = early_mid_results, mid_late = mid_late_results))
}

# 获取所有 CSV 文件路径
csv_files <- list.files(data_folder, pattern = "\\.csv$", full.names = TRUE)
xlsx_files <- list.files(group_folder, pattern = "_community_results\\.xlsx$", full.names = TRUE)

# 获取所有地点
locations <- unique(sapply(csv_files, extract_location))

# 按地点处理数据
for (location in locations) {
  location_files <- csv_files[grep(paste0("^", location, "——"), basename(csv_files))]
  
  if (length(location_files) == 0) {
    warning(paste("No data files found for location", location))
    next
  }
  
  # 创建一个新的工作簿
  wb <- createWorkbook()
  
  # 读取分组数据
  group_data_file <- xlsx_files[grep(paste0("^", location, "_"), basename(xlsx_files))]
  if (length(group_data_file) == 1) {
    group_data <- read_excel(group_data_file)
  } else {
    warning(paste("Group data file for location", location, "not found or multiple files found."))
    next
  }
  
  # 打印调试信息
  print(paste("Processing location:", location))
  
  # 合并该地点的所有时期数据，构建相似矩阵
  all_data <- lapply(location_files, read.csv) %>% bind_rows()
  distinct_data <- all_data %>% distinct(name, .keep_all = TRUE)
  distinct_data <- distinct_data[, -2]
  distinct_data <- distinct_data %>% mutate(across(-name, scale))
  trait_data <- distinct_data[, -1]
  similarity_matrix <- proxy::simil(trait_data, method = "cosine")
  similarity_matrix <- as.matrix(similarity_matrix)
  rownames(similarity_matrix) <- distinct_data$name
  colnames(similarity_matrix) <- distinct_data$name
  similarity_matrix[similarity_matrix > 1] <- 1
  similarity_matrix[similarity_matrix < 0] <- 0
  
  # 处理每个时期
  period_results <- list()
  for (file_path in location_files) {
    period <- extract_period(file_path)
    data <- read.csv(file_path)
    species_names <- data$name
    
    # 进行灭绝模拟
    results <- simulate_extinction(similarity_matrix, species_names, group_data)
    period_results[[period]] <- results
    
    # 将结果添加到工作簿中
    addWorksheet(wb, period)
    writeData(wb, period, results)
  }
  
  # 如果有所有三个时期的数据，则提取结果
  if (all(c("early", "mid", "late") %in% names(period_results))) {
    combined_results <- extract_results(
      early_data = period_results$early,
      mid_data = period_results$mid,
      late_data = period_results$late,
      early_results = period_results$early,
      mid_results = period_results$mid,
      late_results = period_results$late
    )
    
    addWorksheet(wb, "Early-Mid")
    writeData(wb, "Early-Mid", combined_results$early_mid)
    
    addWorksheet(wb, "Mid-Late")
    writeData(wb, "Mid-Late", combined_results$mid_late)
  }
  
  # 保存工作簿
  saveWorkbook(wb, file.path(output_folder, paste0(location, "_network_extinction_simulation.xlsx")), overwrite = TRUE)
  
  print(paste0("Results for location '", location, "' saved to '", file.path(output_folder, paste0(location, "_network_extinction_simulation.xlsx")), "'"))
}
