######### 预聚类
# 载入必要的库
library(dplyr)
library(proxy)
library(igraph)
library(openxlsx)

# 读取所有CSV文件并合并
files <- list.files(path = "data_ori", pattern = "\\.csv$", full.names = TRUE)
all_data <- lapply(files, read.csv, header = TRUE) %>% bind_rows()

# 去重，假设'name'列包含物种名
distinct_data <- all_data %>% distinct(name, .keep_all = TRUE)
distinct_data <- distinct_data[, -2]

# 预处理数据，假设第一列是物种名
# 使用dplyr进行数据标准化
distinct_data <- distinct_data %>%
  mutate(across(-name, scale))  # 假设第一列是名为'name'的物种名称列
trait_data <- distinct_data[, -1]

# 计算相似度矩阵
similarity <- proxy::simil(trait_data, method = "cosine")
similarity <- as.matrix(similarity)

# 确保行名和列名正确
rownames(similarity) <- distinct_data$name
colnames(similarity) <- distinct_data$name

# 将相似度矩阵中的不合理值调整为合理范围
similarity[similarity > 1] <- 1
similarity[similarity < 0] <- 0

######### 3D。 合并所有状态外壳 
# 提取文件名中的地名和时期信息的函数
extract_info_from_filename <- function(filename) {
  name_parts <- strsplit(basename(filename), "——")[[1]]
  location <- name_parts[1]
  period <- name_parts[2]
  period <- sub(".csv", "", period)
  return(list(location = location, period = period))
}

# 计算物种状态的函数
calculate_species_status <- function(data1, data2) {
  new_species <- setdiff(data2$name, data1$name)
  disappeared_species <- setdiff(data1$name, data2$name)
  constant_species <- intersect(data1$name, data2$name)
  
  status <- data.frame(
    name = c(new_species, disappeared_species, constant_species),
    status = c(rep("new", length(new_species)), 
               rep("disappeared", length(disappeared_species)), 
               rep("constant", length(constant_species)))
  )
  
  return(status)
}

# 读取数据并提取信息
early_data_filename <- "data_ori/LGH——HIS.csv"
mid_data_filename <- "data_ori/LGH——7080.csv"
late_data_filename <- "data_ori/LGH——now.csv"

early_data_info <- extract_info_from_filename(early_data_filename)
mid_data_info <- extract_info_from_filename(mid_data_filename)
late_data_info <- extract_info_from_filename(late_data_filename)

early_data <- read.csv(early_data_filename)
mid_data <- read.csv(mid_data_filename)
late_data <- read.csv(late_data_filename)
similarity_matrix <- similarity  # 确保 similarity 是相似度矩阵的变量名

# 合并数据
merged_early_mid <- unique(rbind(early_data, mid_data))
merged_mid_late <- unique(rbind(mid_data, late_data))

# 计算物种状态
early_mid_status <- calculate_species_status(early_data, mid_data)
mid_late_status <- calculate_species_status(mid_data, late_data)

# 创建网络图对象
Isite_Fin_early_mid <- similarity_matrix[merged_early_mid$name, merged_early_mid$name]
diag(Isite_Fin_early_mid) <- 0
Isite_Fin_early_mid[Isite_Fin_early_mid < 0] <- 0
Isite_net_early_mid <- graph_from_adjacency_matrix(Isite_Fin_early_mid, weighted = TRUE, mode = 'undirected')

Isite_Fin_mid_late <- similarity_matrix[merged_mid_late$name, merged_mid_late$name]
diag(Isite_Fin_mid_late) <- 0
Isite_Fin_mid_late[Isite_Fin_mid_late < 0] <- 0
Isite_net_mid_late <- graph_from_adjacency_matrix(Isite_Fin_mid_late, weighted = TRUE, mode = 'undirected')

# 生成3D布局
layout_3d_early_mid <- layout_with_fr(Isite_net_early_mid, dim = 3)
layout_3d_mid_late <- layout_with_fr(Isite_net_mid_late, dim = 3)

# 返回3D坐标和网络对象
list(
  early_mid = list(network = Isite_net_early_mid, layout = layout_3d_early_mid),
  mid_late = list(network = Isite_net_mid_late, layout = layout_3d_mid_late)
)
# 计算网络中的所有三角形
calculate_triangles <- function(network) {
  triangles_list <- triangles(network)
  triangles_matrix <- matrix(triangles_list, ncol = 3, byrow = TRUE)
  return(triangles_matrix)
}

# 生成零模型网络的函数
generate_null_model <- function(network, status_counts) {
  node_names <- V(network)$name
  repeat {
    random_status <- sample(c(rep("new", status_counts["new"]),
                              rep("disappeared", status_counts["disappeared"]),
                              rep("constant", status_counts["constant"]),
                              rep("other", vcount(network) - sum(status_counts))))
    if (!all(V(network)$status == random_status)) {
      break
    }
  }
  null_network <- network
  V(null_network)$status <- random_status
  return(null_network)
}

# 生成3D布局并计算三角形分析
# 调整后的process_triangles函数，去除百分比计算
process_triangles_without_percentage <- function(network, status_data, title, period, location) {
  V(network)$status <- ifelse(V(network)$name %in% status_data$name, status_data$status[match(V(network)$name, status_data$name)], "other")
  
  status_counts <- table(V(network)$status)
  required_states <- c("new", "disappeared", "constant")
  missing_states <- setdiff(required_states, names(status_counts))
  
  if (length(missing_states) > 0 || any(status_counts[required_states] < 1, na.rm = TRUE)) {
    return(data.frame(
      Period = period,
      Location = location,
      State_Species_Scenarios = "NED",
      Total_Triangles = "NED",
      Null_Model_Mean_Scenarios = "NED",
      Null_Model_Scenarios_SD = "NED",
      Z_score = "NED",
      P_value = "NED"
    ))
  }
  
  triangles <- calculate_triangles(network)
  if (nrow(triangles) == 0) {
    return(data.frame(
      Period = period,
      Location = location,
      State_Species_Scenarios = "NED",
      Total_Triangles = "NED",
      Null_Model_Mean_Scenarios = "NED",
      Null_Model_Scenarios_SD = "NED",
      Z_score = "NED",
      P_value = "NED"
    ))
  }
  
  scenario_count <- sum(apply(triangles, 1, function(triangle) {
    states <- V(network)$status[triangle]
    if (sum(states == "disappeared") == 1 && sum(states == "constant") == 2) {
      disappeared_node <- triangle[states == "disappeared"]
      constant_nodes <- triangle[states == "constant"]
      for (i in 1:vcount(network)) {
        if (V(network)$status[i] == "new") {
          new_node <- i
          if (new_node %in% neighbors(network, constant_nodes[1]) &&
              new_node %in% neighbors(network, constant_nodes[2]) &&
              new_node %in% neighbors(network, disappeared_node)) {
            return(TRUE)
          }
        }
      }
    }
    return(FALSE)
  }))
  total_triangles <- nrow(triangles)
  
  null_scenario_counts <- numeric(1000)
  pb <- txtProgressBar(min = 0, max = 1000, style = 3)
  
  for (i in 1:1000) {
    null_model <- generate_null_model(network, status_counts)
    null_triangles <- calculate_triangles(null_model)
    
    if (nrow(null_triangles) == 0) {
      next
    }
    
    null_scenario_counts[i] <- sum(apply(null_triangles, 1, function(triangle) {
      states <- V(null_model)$status[triangle]
      if (sum(states == "disappeared") == 1 && sum(states == "constant") == 2) {
        disappeared_node <- triangle[states == "disappeared"]
        constant_nodes <- triangle[states == "constant"]
        for (j in 1:vcount(null_model)) {
          if (V(null_model)$status[j] == "new") {
            new_node <- j
            if (new_node %in% neighbors(null_model, constant_nodes[1]) &&
                new_node %in% neighbors(null_model, constant_nodes[2]) &&
                new_node %in% neighbors(null_model, disappeared_node)) {
              return(TRUE)
            }
          }
        }
      }
      return(FALSE)
    }))
    
    setTxtProgressBar(pb, i)
  }
  
  close(pb)
  
  null_mean <- mean(null_scenario_counts)
  null_sd <- sd(null_scenario_counts)
  z_score <- (scenario_count - null_mean) / null_sd
  p_value <- 2 * (1 - pnorm(abs(z_score)))
  
  if (p_value == 0) {
    p_value <- .Machine$double.eps
  }
  
  return(data.frame(
    Period = period,
    Location = location,
    State_Species_Scenarios = scenario_count,
    Total_Triangles = total_triangles,
    Null_Model_Mean_Scenarios = null_mean,
    Null_Model_Scenarios_SD = null_sd,
    Z_score = z_score,
    P_value = p_value
  ))
}

# 初始化结果数据框
results_df <- data.frame()

# 处理每个时期的网络并不包含百分比计算
results_df <- rbind(results_df, process_triangles_without_percentage(Isite_net_early_mid, early_mid_status, "Early-Mid Period", "Early-Mid", early_data_info$location))
results_df <- rbind(results_df, process_triangles_without_percentage(Isite_net_mid_late, mid_late_status, "Mid-Late Period", "Mid-Late", mid_data_info$location))

# 保存结果到Excel文件
write.xlsx(results_df, file = paste0("Hyp_test/results_", early_data_info$location, ".xlsx"))
