#################设定解释率#####
#功能丰富度(FRic)的计算参考：
#Mathematically, the FRic index is based on the convex hull concept
#(i.e. the minimum convex hull which includes all species considered, Cornwell et al., 2006，A trait-based test for habitat filtering: convex hull volume), 
#and corresponds to the volume contained within this hull (Villéger et al., 2008，New multidimensional functional diversity indices for a multifaceted framework in functional ecology). 
#This volume is computed after projection of each species according to their trait values in a multidimensional space 
#where each dimension represents a functional trait

#功能离散度（FDiv）的计算参考：
#Villéger S, Mason N W H, Mouillot D. 
#New Multidimensional Functional Diversity Indices 
#For A Multifaceted Framework In Functional Ecology[J]. Ecology, 2008, 89(8): 2290-2301.

library(geometry)
library(vegan)
library(dplyr)
library(openxlsx)
library(readxl)

# 计算功能离散度（FDis）的函数
calc_FDis <- function(traits_transformed, abundances = NULL) {
  if (is.null(abundances)) {
    abundances <- rep(1, nrow(traits_transformed))
  }
  centroid <- colMeans(traits_transformed)
  dist_to_centroid <- sqrt(rowSums((traits_transformed - centroid)^2))
  fdis <- sum(abundances * dist_to_centroid) / sum(abundances)
  return(fdis)
}


# 计算功能离散度（FDiv）的函数
calc_FDiv <- function(traits_transformed) {
  centroid <- colMeans(traits_transformed)
  dist_to_centroid <- sqrt(rowSums((traits_transformed - centroid)^2))
  mean_dist <- mean(dist_to_centroid)
  fdiv <- sum((dist_to_centroid - mean_dist)^2) / sum(dist_to_centroid^2)
  return(fdiv)
}

# 计算功能原创性（FOri）的函数（基于最近邻居的距离）
calc_FOri <- function(traits_transformed) {
  dist_matrix <- as.matrix(dist(traits_transformed))
  diag(dist_matrix) <- Inf # 将对角线元素设为无穷大，防止自己和自己比较
  nearest_neighbor_dist <- apply(dist_matrix, 1, min)
  return(mean(nearest_neighbor_dist)) # 返回平均值
}

# 计算功能丰富度（FRic）、功能离散度（FDiv）、功能离散度（FDis）和功能原创性（FOri）
calculate_indices <- function(data, num_axes) {
  traits_transformed <- as.matrix(data[, 1:num_axes]) # 提取指定数量的主成分的得分
  
  # 如果点数不足以形成凸包，则返回NA
  if (nrow(traits_transformed) < (num_axes + 1)) {
    return(list(FRic = NA, FDiv = NA, FDis = NA, FOri = NA))
  }
  
  # 计算功能丰富度 (FRic)
  hull <- convhulln(traits_transformed, options = "FA")
  functional_richness <- hull$vol
  
  # 计算功能离散度 (FDiv)
  functional_divergence <- calc_FDiv(traits_transformed)
  
  # 计算功能离散度 (FDis)
  functional_dispersion <- calc_FDis(traits_transformed)
  
  # 计算功能原创性 (FOri)
  functional_originality <- calc_FOri(traits_transformed)
  
  return(list(FRic = functional_richness, FDiv = functional_divergence, FDis = functional_dispersion, FOri = functional_originality))
}

# 模拟物种消失并计算功能多样性指数变化
simulate_extinction <- function(data, num_axes) {
  original_pca <- prcomp(data, center = TRUE, scale. = TRUE)
  original_scores <- as.matrix(original_pca$x[, 1:num_axes])
  original_indices <- calculate_indices(as.data.frame(original_scores), num_axes)
  
  results <- data.frame(Species = rownames(data), 
                        FRic = original_indices$FRic, 
                        FDiv = original_indices$FDiv, 
                        FDis = original_indices$FDis,
                        FOri = original_indices$FOri, # 计算整个社区的FOri
                        FRic_Difference = 0, 
                        FDiv_Difference = 0, 
                        FDis_Difference = 0,
                        FOri_Difference = 0,
                        FRic_Percent_Change = 0,
                        FDiv_Percent_Change = 0,
                        FDis_Percent_Change = 0,
                        FOri_Percent_Change = 0)
  
  for (i in 1:nrow(data)) {
    temp_data <- data[-i, ]
    temp_pca <- prcomp(temp_data, center = TRUE, scale. = TRUE)
    temp_scores <- as.matrix(temp_pca$x[, 1:num_axes])
    temp_indices <- calculate_indices(as.data.frame(temp_scores), num_axes)
    
    fric_difference <- temp_indices$FRic - original_indices$FRic
    fdiv_difference <- temp_indices$FDiv - original_indices$FDiv
    fdis_difference <- temp_indices$FDis - original_indices$FDis
    fori_difference <- temp_indices$FOri - original_indices$FOri
    
    fric_percent_change <- (fric_difference / original_indices$FRic) * 100
    fdiv_percent_change <- (fdiv_difference / original_indices$FDiv) * 100
    fdis_percent_change <- (fdis_difference / original_indices$FDis) * 100
    fori_percent_change <- (fori_difference / original_indices$FOri) * 100
    
    results[i, c("FRic_Difference", "FDiv_Difference", "FDis_Difference", "FOri_Difference",
                 "FRic_Percent_Change", "FDiv_Percent_Change", "FDis_Percent_Change", "FOri_Percent_Change")] <- 
      c(fric_difference, fdiv_difference, fdis_difference, fori_difference, 
        fric_percent_change, fdiv_percent_change, fdis_percent_change, fori_percent_change)
  }
  
  return(results)
}
# 读取数据
early_data <- read.csv("LGH——HIS.csv")
mid_data <- read.csv("LGH——7080.csv")
late_data <- read.csv("LGH——now.csv")

# 设置累积解释率阈值
threshold <- 0.95

# 自动选择 PCA 轴数量的函数
select_num_axes <- function(pca_summary, threshold) {
  cumulative_variance <- pca_summary$importance[3, ]
  num_axes <- which(cumulative_variance >= threshold)[1]
  return(num_axes)
}

# 进行 PCA 分析并自动选择 PCA 轴数量
# Early period
rownames(early_data) <- early_data[,1]
early_data <- early_data[,-1]
early_data <- early_data[,-1]
early_pca <- prcomp(early_data, center = TRUE, scale. = TRUE)
early_num_axes <- select_num_axes(summary(early_pca), threshold)
print("Early period PCA variance explained:")
print(summary(early_pca)$importance[2, ]) # 获取每个主成分的方差解释率
print(summary(early_pca)$importance[3, ]) # 获取累积的方差解释率

# Mid period
rownames(mid_data) <- mid_data[,1]
mid_data <- mid_data[,-1]
mid_data <- mid_data[,-1]
mid_pca <- prcomp(mid_data, center = TRUE, scale. = TRUE)
mid_num_axes <- select_num_axes(summary(mid_pca), threshold)
print("Mid period PCA variance explained:")
print(summary(mid_pca)$importance[2, ]) # 获取每个主成分的方差解释率
print(summary(mid_pca)$importance[3, ]) # 获取累积的方差解释率

# Late period
rownames(late_data) <- late_data[,1]
late_data <- late_data[,-1]
late_data <- late_data[,-1]
late_pca <- prcomp(late_data, center = TRUE, scale. = TRUE)
late_num_axes <- select_num_axes(summary(late_pca), threshold)
print("Late period PCA variance explained:")
print(summary(late_pca)$importance[2, ]) # 获取每个主成分的方差解释率
print(summary(late_pca)$importance[3, ]) # 获取累积的方差解释率

# Early period
early_results <- simulate_extinction(early_data, early_num_axes)

# Mid period
mid_results <- simulate_extinction(mid_data, mid_num_axes)

# Late period
late_results <- simulate_extinction(late_data, late_num_axes)

# 判断物种状态并提取结果
extract_results <- function(early_data, mid_data, late_data, early_results, mid_results, late_results) {
  # Early-Mid period
  early_species <- rownames(early_data)
  mid_species <- rownames(mid_data)
  
  early_mid_status <- data.frame(Species = unique(c(early_species, mid_species)), Status = NA)
  early_mid_status$Status[early_mid_status$Species %in% early_species & !early_mid_status$Species %in% mid_species] <- "disappear"
  early_mid_status$Status[early_mid_status$Species %in% mid_species & !early_mid_status$Species %in% early_species] <- "new"
  early_mid_status$Status[early_mid_status$Species %in% early_species & early_mid_status$Species %in% mid_species] <- "unchanged"
  
  early_mid_results <- rbind(
    early_results[early_results$Species %in% early_mid_status$Species[early_mid_status$Status == "disappear"], ],
    mid_results[mid_results$Species %in% early_mid_status$Species[early_mid_status$Status != "disappear"], ]
  )
  early_mid_results <- merge(early_mid_results, early_mid_status, by = "Species")
  
  # Mid-Late period
  mid_species <- rownames(mid_data)
  late_species <- rownames(late_data)
  
  mid_late_status <- data.frame(Species = unique(c(mid_species, late_species)), Status = NA)
  mid_late_status$Status[mid_late_status$Species %in% mid_species & !mid_late_status$Species %in% late_species] <- "disappear"
  mid_late_status$Status[mid_late_status$Species %in% late_species & !mid_late_status$Species %in% mid_species] <- "new"
  mid_late_status$Status[mid_late_status$Species %in% mid_species & mid_late_status$Species %in% late_species] <- "unchanged"
  
  mid_late_results <- rbind(
    mid_results[mid_results$Species %in% mid_late_status$Species[mid_late_status$Status == "disappear"], ],
    late_results[late_results$Species %in% mid_late_status$Species[mid_late_status$Status != "disappear"], ]
  )
  mid_late_results <- merge(mid_late_results, mid_late_status, by = "Species")
  
  return(list(early_mid = early_mid_results, mid_late = mid_late_results))
}

results <- extract_results(early_data, mid_data, late_data, early_results, mid_results, late_results)

# 保存结果到 Excel 文件
wb <- createWorkbook()

# 保留原来的结果
addWorksheet(wb, paste0("Early (", early_num_axes, " axes)"))
writeData(wb, paste0("Early (", early_num_axes, " axes)"), early_results)

addWorksheet(wb, paste0("Mid (", mid_num_axes, " axes)"))
writeData(wb, paste0("Mid (", mid_num_axes, " axes)"), mid_results)

addWorksheet(wb, paste0("Late (", late_num_axes, " axes)"))
writeData(wb, paste0("Late (", late_num_axes, " axes)"), late_results)

# 添加新生成的结果
addWorksheet(wb, "Early-Mid")
writeData(wb, "Early-Mid", results$early_mid)

addWorksheet(wb, "Mid-Late")
writeData(wb, "Mid-Late", results$mid_late)

saveWorkbook(wb, "functional_diversity_extinction_simulation.xlsx", overwrite = TRUE)

print("Results saved to 'functional_diversity_extinction_simulation.xlsx'")


########归一化后计算相对距离######

# 加载必要的R包
library(readxl)
library(openxlsx)
library(dplyr)

# 读取数据
data <- read_excel("total-grouped.xlsx")

# 显示列名
print(colnames(data))

# 设置x轴和y轴列名（例如，x_col和y_col），以及物种状态列名（例如，status_col）
x_col <- "FRic_Percent_Change"
y_col <- "FDis_Percent_Change"
status_col <- "Status"
group_col <- "group"  # 分组列

# 归一化函数
normalize <- function(x) {
  return((x - min(x)) / (max(x) - min(x)))
}

# 对x_col和y_col进行归一化
data[[x_col]] <- normalize(data[[x_col]])
data[[y_col]] <- normalize(data[[y_col]])

# 计算每个物种距离原点的距离
data <- data %>%
  mutate(role_distance = sqrt((data[[x_col]])^2 + (data[[y_col]])^2))

# 显示更新后的数据框
print(head(data))

# 将数据保存到新的Excel文件
write.xlsx(data, "total_grouped_with_distances.xlsx")

print


############# 坐标进行转换 ##########
# 加载必要的R包
library(readxl)
library(ggplot2)
library(ggExtra)
library(dplyr)
library(vegan)

# 读取数据
data <- read_excel("total-grouped.xlsx")

# 显示列名
print(colnames(data))

# 设置x轴和y轴列名（例如，x_col和y_col），以及物种状态列名（例如，status_col）
x_col <- "FRic_Percent_Change"
y_col <- "FDis_Percent_Change"
status_col <- "Status"
group_col <- "group"  # 分组列

# 归一化函数
normalize <- function(x) {
  return((x - min(x)) / (max(x) - min(x)))
}

# 对x_col和y_col进行归一化
data[[x_col]] <- normalize(data[[x_col]])
data[[y_col]] <- normalize(data[[y_col]])

# 根据数据中的实际物种状态值设置颜色
status_values <- unique(data[[status_col]])
color_values <- c("disappear" = "#F62AA0", "new" = "#F8CF40", "unchanged" = "#025492")

# 获取所有数据的x和y轴范围
x_range <- range(data[[x_col]], na.rm = TRUE)
y_range <- range(data[[y_col]], na.rm = TRUE)

# 定义自定义函数进行两两比较
pairwise.permanova <- function(data, x_col, y_col, status_col) {
  levels <- unique(data[[status_col]])
  n <- length(levels)
  results <- list()
  
  for (i in 1:(n-1)) {
    for (j in (i+1):n) {
      level1 <- levels[i]
      level2 <- levels[j]
      subset_data <- data[data[[status_col]] %in% c(level1, level2), ]
      dist_matrix <- dist(subset_data[, c(x_col, y_col)])
      adonis_res <- adonis2(dist_matrix ~ subset_data[[status_col]], permutations = 999)
      p_value <- adonis_res$`Pr(>F)`[1]
      results[[paste(level1, "vs", level2)]] <- p_value
    }
  }
  return(results)
}

# 设置要分析的分组，或者选择 "all" 表示所有分组
selected_group <- "2"  # 替换为具体的分组编号，或者使用 "all" 表示所有分组

# 检查是否有分组列并选择特定分组的数据
if (selected_group == "all") {
  # 使用所有数据
  group_data <- data
} else if (!is.null(group_col) && group_col %in% colnames(data)) {
  if (selected_group %in% unique(data[[group_col]])) {
    group_data <- data %>% filter(!!sym(group_col) == selected_group)
  } else {
    stop(paste("Selected group", selected_group, "not found in the data."))
  }
} else {
  stop("Group column not found in the data.")
}

# 执行两两比较
pairwise_results <- pairwise.permanova(group_data, x_col, y_col, status_col)

# 显示结果
print(pairwise_results)

# 绘制散点图，增大散点大小，并添加外框和从0开始的坐标轴
p <- ggplot(group_data, aes_string(x = x_col, y = y_col, color = status_col)) +
  geom_point(alpha = 0.6, size = 6) + # 绘制散点图并增大散点大小
  scale_color_manual(values = color_values) + # 根据状态设置颜色
  scale_x_continuous(limits = x_range, expand = expansion(mult = c(0.05, 0.1))) + # 使用所有数据的x轴范围
  scale_y_continuous(limits = y_range, expand = expansion(mult = c(0.05, 0.1))) + # 使用所有数据的y轴范围
  theme_minimal() + # 设置主题
  theme(panel.border = element_rect(color = "black", fill = NA, size = 1), # 添加外框
        axis.line = element_line(color = "black"), # 设置坐标轴
        axis.ticks = element_line(color = "black"), # 显示刻度
        axis.text = element_text(color = "black"), # 显示刻度标签
        panel.grid = element_blank()) + # 移除网格线
  labs(title = if (selected_group == "all") "All Groups" else paste("Group:", selected_group),
       x = x_col,
       y = y_col,
       color = "Species Status") # 添加标签


# 使用ggMarginal添加边缘密度图
p_with_marginals <- ggMarginal(p, type = "density", groupColour = TRUE, groupFill = TRUE)

# 打印图形
print(p_with_marginals)