#############固定性状顺序#######
library(nnet)
library(readxl)
library(reshape2)
library(ggplot2)
library(writexl)

# 读取物种状态数据
species_status <- read_excel("species changg.xlsx")

# 读取功能性状数据
traits_data <- read_excel("distinct_data.xlsx")

# 合并两个数据集
merged_data <- merge(species_status, traits_data, by = "name")

# 确保status列是因子类型
merged_data$Status <- as.factor(merged_data$Status)

# 查看数据结构
str(merged_data)

# 使用多项logistic回归模型
# 将所有功能性状列作为自变量
trait_columns <- colnames(traits_data)[-1]  # 假设第1列是name，排除掉
formula <- as.formula(paste("Status ~", paste(trait_columns, collapse = " + ")))

# 假设基线状态是 "disappeared"
# 如果你想设置 "disappeared" 为基线状态
# merged_data$Status <- relevel(merged_data$Status, ref = "disappeared")

# 训练模型
multinom_model <- multinom(formula, data = merged_data)

# 查看模型摘要
summary(multinom_model)

# Calculate z-values and p-values
z_values <- summary(multinom_model)$coefficients / summary(multinom_model)$standard.errors
p_values <- (1 - pnorm(abs(z_values), 0, 1)) * 2

# Convert matrices to data frames
z_values_df <- as.data.frame(z_values)
p_values_df <- as.data.frame(p_values)

# Display z-values and p-values
print("Z-values:")
print(z_values_df)
print("P-values:")
print(p_values_df)

# 提取 new 类别的 z 值和 p 值，排除 Intercept 列
z_values_new <- z_values_df["new", -1] # -1 表示排除第一列 Intercept
p_values_new <- p_values_df["new", -1]

# 创建用于可视化的数据框，排除 Intercept 列
variable_importance <- data.frame(
  Variable = colnames(z_values_df)[-1], # 排除 Intercept 列
  z_value = as.numeric(z_values_new),
  p_value = round(as.numeric(p_values_new), 2)  # 保留两位小数
)

# 添加颜色列，p值小于或等于0.05时用原始颜色，否则用灰色
variable_importance$color <- ifelse(variable_importance$p_value <= 0.05, "#3d3d3d", "gray")

# 找到Z值的最大绝对值，用于对称坐标轴
max_abs_z_value <- max(abs(variable_importance$z_value))

# 定义性状的固定顺序，按所需顺序排列
fixed_order <- c("tm", "BEI", "M", "CPt", "PFs", "Troph", "L_maturity", "OGp", "BLs", "RMI", "PFv", "VEp", "REs", "generation_time")

# 确保 Variable 因子的顺序
variable_importance$Variable <- factor(variable_importance$Variable, levels = fixed_order)

# 使用 ggplot2 绘制 z 值的重要性图，固定 y 轴顺序
ggplot(variable_importance, aes(x = Variable, y = z_value, fill = color)) +
  geom_bar(stat = "identity") +
  scale_fill_manual(values = c("#3d3d3d" = "#3d3d3d", "gray" = "gray")) +  # 定义颜色
  coord_flip(ylim = c(-max_abs_z_value, max_abs_z_value)) +  # 对称坐标轴
  xlab("Traits") +
  ylab("Z-value") +
  ggtitle("Variable Importance (Z-values) in Multinomial Logistic Regression for 'new' Category") +
  theme_minimal() +  # 使用简洁的主题
  theme(
    panel.border = element_rect(color = "black", fill = NA),  # 添加边框
    axis.ticks = element_line(color = "black"),  # 显示刻度
    axis.line = element_line(color = "black")  # 显示轴线
  )

# 提取 unchanged 类别的 z 值和 p 值，排除 Intercept 列
z_values_unchanged <- z_values_df["unchanged", -1] # -1 表示排除第一列 Intercept
p_values_unchanged <- p_values_df["unchanged", -1]

# 创建用于可视化的数据框，排除 Intercept 列
variable_importance <- data.frame(
  Variable = colnames(z_values_df)[-1], # 排除 Intercept 列
  z_value = as.numeric(z_values_unchanged),
  p_value = round(as.numeric(p_values_unchanged), 2)  # 保留两位小数
)

# 添加颜色列，p值小于或等于0.05时用原始颜色，否则用灰色
variable_importance$color <- ifelse(variable_importance$p_value <= 0.05, "#3d3d3d", "gray")

# 确保 Variable 因子的顺序
variable_importance$Variable <- factor(variable_importance$Variable, levels = fixed_order)

# 找到Z值的最大绝对值，用于对称坐标轴
max_abs_z_value <- max(abs(variable_importance$z_value))

# 使用 ggplot2 绘制 z 值的重要性图，固定 y 轴顺序
ggplot(variable_importance, aes(x = Variable, y = z_value, fill = color)) +
  geom_bar(stat = "identity") +
  scale_fill_manual(values = c("#3d3d3d" = "#3d3d3d", "gray" = "gray")) +  # 定义颜色
  coord_flip(ylim = c(-max_abs_z_value, max_abs_z_value)) +  # 对称坐标轴
  xlab("Traits") +
  ylab("Z-value") +
  ggtitle("Variable Importance (Z-values) in Multinomial Logistic Regression for 'unchanged' Category") +
  theme_minimal() +  # 使用简洁的主题
  theme(
    panel.border = element_rect(color = "black", fill = NA),  # 添加边框
    axis.ticks = element_line(color = "black"),  # 显示刻度
    axis.line = element_line(color = "black")  # 显示轴线
  )
