############################
############################    构建系统发育树，补充生活史数据的缺失值
# Imputation of missing data in life‐history trait datasets: which approach performs the best?
#############################################
library(quadprog)
library(FishPhyloMaker)
library(dplyr)
library(fishtree)
library(phytools)
library(readxl)
library(Rphylopars)
# 创建函数
merge_csv_files <- function(dir_path){
  # 获取工作目录下所有的.csv文件
  files <- list.files(dir_path, pattern = "\\.csv$", full.names = TRUE)
  
  # 初始化空的data frame
  all_data <- data.frame()
  
  # 遍历文件列表
  for(file in files){
    # 读取.csv文件
    data <- read.csv(file)
    
    # 检查是否有"name"列
    if(!"name" %in% names(data)){
      stop(paste("Column 'name' not found in file:", file))
    }
    
    # 添加数据到总的data frame中
    all_data <- bind_rows(all_data, data)
  }
  
  # 去掉"name"列中的重复值
  all_data <- all_data[!duplicated(all_data$name), ]
  
  # 返回合并后的数据
  return(all_data)
}

# 使用函数
mydata1 <- merge_csv_files(getwd()) # getwd()获取当前工作目录

# Load your data, assume your dataframe is mydata1, the first column is species labels, the rest columns are features for clustering


# 查找重复的行名称
duplicated_rows <- mydata1[duplicated(mydata1[,1]) | duplicated(mydata1[,1], fromLast = TRUE),]

# 输出重复的行名称
print(duplicated_rows)
rownames(mydata1) <- mydata1[,1]


# 2. 处理mydata1以提取拉丁名
mydata1$latin_name <- sapply(strsplit(as.character(mydata1$name), "——"), "[[", 1)
mydata1$latin_name <- gsub(" ", "_", mydata1$latin_name)
mydata1<-read.csv("mydata.csv")
# 3. 使用FishTaxaMaker函数从mydata1数据中的鱼类拉丁名获取它们的Family和Order
taxa_info <- FishTaxaMaker(mydata1$latin.name)
save(taxa_info, file = "taxa_info.RData")


# 读取CSV文件
phy_data <- read.csv(file_path)
phy_data <- phy_data[,-1]
load("taxa_info.RData")
phy_data <-load("taxa_info.RData")
phy_data <- taxa_info$All_info_fishbase[, c("valid_names", "Family", "Order")]
colnames(phy_data) <- c("s", "f", "o")
phy_data <- read.csv("phy_data.csv")#手动补全的物种信息
phy_data <- phy_data[,-1]
# 5. 使用FishPhyloMaker函数获取鱼类的系统发育
res_phylo <- FishPhyloMaker(data = phy_data,
                            insert.base.node = TRUE, 
                            return.insertions = TRUE, 
                            progress.bar = TRUE)

phylo_tree <- res_phylo$Phylogeny
traits_data <- read_excel("missingdata.xlsx")


colnames(traits_data)[1] <- "species"
# # 假设数据中包含物种名称的列，将其设置为行名
# rownames(traits_data) <- traits_data$name
# traits_data$species <- gsub("_", " ", traits_data$species)

# 使用phylopars函数进行缺失值估算
phylopars_result <- phylopars(trait_data = traits_data, tree = phylo_tree)

traits_data_log <- traits_data
traits_data_log[ , -1] <- log1p(traits_data_log[ , -1])  # 排除第一列'species'
phylopars_result <- phylopars(trait_data = traits_data_log, tree = phylo_tree, model = "BM")
# 提取补充完成的数据
imputed_traits <- phylopars_result$anc_recon

# 将对数变换的数据反变换回原始尺度
imputed_traits <- expm1(imputed_traits)

library(writexl)
# 将补充完成的数据转换为数据框
imputed_traits_df <- as.data.frame(imputed_traits)

# 将行名转换为数据框的一列
imputed_traits_df$species <- rownames(imputed_traits_df)

# 重新排列列顺序，将species列放在第一列
imputed_traits_df <- imputed_traits_df[, c("species", colnames(imputed_traits_df)[-ncol(imputed_traits_df)])]

# 保存为 Excel 文件
write_xlsx(imputed_traits_df, "imputed_traits_with_species.xlsx")
